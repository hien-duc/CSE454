<?php
// Add post thumbnails feature
add_theme_support('post-thumbnails');

register_nav_menus(
    array(
        "main-menu" => "Main Menu",
        "product-menu" => "Product Menu",
        "footer-menu" => "Footer Menu"
    )
);